ENT.Type = "anim"
ENT.Base = "base_entity"
 
ENT.PrintName		= "StickyShocker"
ENT.Author			= "WasabiThumbs"
ENT.Contact			= "Please don't"
ENT.Purpose			= "To pass butter."
ENT.Instructions	= "Avoid at all costs."